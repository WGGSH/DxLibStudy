#include "Enemy.h"

Enemy::Enemy(InGame& _inGame) :Unit(_inGame) {
}

Enemy::~Enemy() {
}

void Enemy::damage(int val) {
	this->life -= val;
}