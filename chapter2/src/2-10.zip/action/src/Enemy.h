#pragma once

#include "Unit.h"
#include "Vec2.h"

class Enemy :public Unit {
protected:
	Position pos;
	Vec2 velocity;
	Vec2 accel;
	int direction;// ����
	float range; // �����蔻��
	int life; // �̗�
	int image; // �摜
public:
	Enemy(InGame&);
	virtual ~Enemy();

	virtual bool update() = 0;
	virtual void draw()const = 0;

	void damage(int);
	const Position& getPos()const { return this->pos; } 
	float getRange()const { return this->range; }
};

#include "EnemyNormal.h"
#include "EnemyFly.h"