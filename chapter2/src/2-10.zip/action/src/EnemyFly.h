#pragma once

#include "Enemy.h"

class EnemyFly : public Enemy {
private:
public:
	EnemyFly(InGame&, Position pos);
	~EnemyFly();

	bool update()override;
	void draw()const;
};

