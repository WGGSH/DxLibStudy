#pragma once

#include "Enemy.h"

class EnemyNormal : public Enemy {
private:
	bool isJumping;
public:
	EnemyNormal(InGame&, Position pos);
	~EnemyNormal();

	bool update()override;
	void draw()const;
};
