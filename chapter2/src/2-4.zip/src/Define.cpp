#include "Define.h"

// �E�B���h�E�T�C�Y
const int Define::WINDOW_WIDTH = 640;
const int Define::WINDOW_HEIGHT = 480;

// �v���C���[�̉摜
// const int Define::PLAYER_IMAGE_NUM = 13;
// const int Define::PLAYER_IMAGE_RUNNING_FRAMES = 6;

// ���w���Z�p
// const float Define::PI = 3.14159265f;
// const float Define::PI2 = Define::PI * 2;
// const float Define::ZERO_VALUE = 0.000001f;

// �Q�[�����萔
// const float Define::GRAVITY = 9.8f*0.02f;
// const float Define::FRICTION = 0.6f;
// const float Define::JUMP_POWER = -7.0f;
// const float Define::PLAYER_ACCEL = 0.6f;
// const float Define::PLAYER_MAX_SPEED = 8.0f;
// const int Define::FIELD_WIDTH = 960;
// const int Define::FIELD_HEIGHT = 720;
// const int Define::DIRECTION_FRONT = 1;
// const int Define::DIRECTION_BACK = -1;