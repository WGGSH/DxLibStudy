﻿#include "./Vec2.h"
#include <cmath>

Vec2::Vec2() :x(0), y(0) {
}

Vec2::Vec2(float _x, float _y) : x(_x), y(_y) {
}

// 内積
float Vec2::dotProduct(const Vec2& other) const {
	return this->x*other.x + this->y*other.y;
}

// 外積
float Vec2::crossProduct(const Vec2& other)const {
	return this->x*other.y - this->y*other.x;
}

// ベクトルの長さ
float Vec2::length()const {
	return std::sqrtf(this->x*this->x + this->y*this->y);
}

// ベクトルの長さの2乗
float Vec2::lengthSquare()const {
	return this->x*this->x + this->y*this->y;
}

// 正規化ベクトル
Vec2 Vec2::normalized()const {
	float length = this->length();
	return{ this->x / length,this->y / length };
}

// 2点間の距離
float Vec2::distance(const Vec2& other)const {
	return (*this + other).length();
}

// ベクトルの角度
float Vec2::angle()const {
	return atan2f(this->y, this->x);
}

// ベクトルの回転
void Vec2::rotate(float angle) {
	*this = Position{ this->x*cosf(angle) - this->y*sinf(angle),this->x*sinf(angle) + this->y*cosf(angle) };
}

// 演算子オーバーロード
Vec2 Vec2::operator+(const Vec2& other)const {
	return{ this->x + other.x, this->y + other.y };
}

Vec2 Vec2::operator-(const Vec2& other)const {
	return{ this->x - other.x,this->y - other.y };
}

Vec2 Vec2::operator*(float scale)const {
	return{ this->x*scale, this->y*scale };
}

Vec2 Vec2::operator/(float scale)const {
	return{ this->x / scale,this->y / scale };
}

Vec2& Vec2::operator+=(const Vec2& other) {
	this->x += other.x;
	this->y += other.y;
	return *this;
}

Vec2& Vec2::operator-=(const Vec2& other) {
	this->x -= other.x;
	this->y -= other.y;
	return *this;
}

Vec2& Vec2::operator*=(float scale) {
	this->x *= scale;
	this->y *= scale;
	return *this;
}

Vec2& Vec2::operator/=(float scale) {
	this->x /= scale;
	this->y /= scale;
	return *this;
}

Vec2 Vec2::operator+()const {
	return *this;
}

Vec2 Vec2::operator-()const {
	return{ -this->x,-this->y };
}

float Vec2::operator*(const Vec2& other)const {
	return this->x*other.x + this->y*other.y;
}