#include "InGame.h"
#include "DxLib.h"
#include "Resource.h"

InGame::InGame() {
	this->image = new int[13];
	// DxLib::LoadDivGraph("Resource/Image/player.png", 13, 13, 1, 48, 96, this->image);
	this->image = Resource::Instance()->getPlayer();
}

InGame::~InGame() {
}


void InGame::update() {
	DxLib::DrawGraph(320, 240, this->image[0], TRUE);
	
	return;
}