#pragma once

class InGame {
private:
	int *image;

public:
	InGame();
	~InGame();

	void update();
};
