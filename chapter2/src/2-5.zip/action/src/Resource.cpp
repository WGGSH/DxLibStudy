#include "Resource.h"
#include "Define.h"

#include "DxLib.h"

// �v���C���[�摜
int* Resource::getPlayer() {
	if (this->player != nullptr)return this->player;
	this->player = new int[Define::PLAYER_IMAGE_NUM];
	DxLib::LoadDivGraph("Resource/Image/player.png", 13, 13, 1, 48, 96, this->player);
	return this->player;
}

// �w�i�摜
/*int Resource::getBackGround() {
	if (this->background > 0)return this->background;
	this->background = DxLib::LoadGraph("Resource/Image/background.png");
	return this->background;
}*/

// ����摜
/*int Resource::getWeapon() {
	if (this->weapon > 0)return this->weapon;
	this->weapon = DxLib::LoadGraph("Resource/Image/weapon.png");
	return this->weapon;
}*/

// �G�L����1
/*int Resource::getEnemyNormal() {
	if (this->enemyNormal > 0)return this->enemyNormal;
	this->enemyNormal = this->player[0];
	return this->enemyNormal;
}*/