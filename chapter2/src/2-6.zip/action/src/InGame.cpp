#include "InGame.h"
#include "DxLib.h"
#include "Resource.h"

InGame::InGame() {
	this->player = new Player(*this);

	this->bgImage = Resource::Instance()->getBackGround();
}

InGame::~InGame() {
}


void InGame::update() {
	// �e�I�u�W�F�N�g�̍X�V
	this->player->update();


	// �e�I�u�W�F�N�g�̕`��
	DxLib::DrawGraph(-this->player->getScrollVec().x, -this->player->getScrollVec().y, this->bgImage, TRUE);
	this->player->draw();
	
	return;
}