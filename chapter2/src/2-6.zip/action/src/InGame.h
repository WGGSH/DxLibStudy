#pragma once
#include "Player.h"

class InGame {
private:
	Player *player;

	int bgImage; // �w�i
public:
	InGame();
	~InGame();

	void update();
};
