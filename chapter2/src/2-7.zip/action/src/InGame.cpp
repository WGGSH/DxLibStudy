#include "InGame.h"
#include "DxLib.h"
#include "Resource.h"

InGame::InGame() {
	this->player = new Player(*this);

	this->bgImage = Resource::Instance()->getBackGround();

	// �u���b�N���X�g�̏�����
	this->blockList.clear();
	this->blockList.push_back(new Block(*this, Position(0, 690), Position(960, 690)));
	this->blockList.push_back(new Block(*this, Position(0, 700), Position(960, 700)));
	this->blockList.push_back(new Block(*this, Position(0, 710), Position(960, 710)));
	this->blockList.push_back(new Block(*this, Position(0, 50), Position(100, 50)));
	this->blockList.push_back(new Block(*this, Position(0, 100), Position(100, 100)));
	this->blockList.push_back(new Block(*this, Position(0, 150), Position(100, 150)));
	this->blockList.push_back(new Block(*this, Position(0, 200), Position(100, 200)));
	this->blockList.push_back(new Block(*this, Position(0, 250), Position(100, 250)));
	this->blockList.push_back(new Block(*this, Position(0, 300), Position(100, 300)));
	this->blockList.push_back(new Block(*this, Position(0, 350), Position(100, 350)));
	this->blockList.push_back(new Block(*this, Position(0, 400), Position(100, 400)));
	this->blockList.push_back(new Block(*this, Position(0, 450), Position(100, 450)));
	this->blockList.push_back(new Block(*this, Position(0, 500), Position(100, 500)));
	this->blockList.push_back(new Block(*this, Position(0, 550), Position(100, 550)));
	this->blockList.push_back(new Block(*this, Position(0, 600), Position(100, 600)));
	this->blockList.push_back(new Block(*this, Position(240, 600), Position(640, 600)));
	this->blockList.push_back(new Block(*this, Position(560, 520), Position(960, 520)));
	this->blockList.push_back(new Block(*this, Position(240, 280), Position(640, 280)));
	this->blockList.push_back(new Block(*this, Position(310, 290), Position(590, 520)));
	this->blockList.push_back(new Block(*this, Position(560, 160), Position(960, 160)));
}

InGame::~InGame() {
}


void InGame::update() {
	// �e�I�u�W�F�N�g�̍X�V
	for (auto block : this->blockList)block->update();
	this->player->update();


	// �e�I�u�W�F�N�g�̕`��
	DxLib::DrawGraph(-this->player->getScrollVec().x, -this->player->getScrollVec().y, this->bgImage, TRUE);
	for (auto block : this->blockList)block->draw();
	this->player->draw();
	
	return;
}