#pragma once
#include "Block.h"
#include "Player.h"
// #include "Enemy.h"

#include <vector>

class Player;

class InGame {
private:
	Player* player;
	int bgImage;

	std::vector<Block*> blockList;

public:
	InGame();
	~InGame();

	void update();

	const Vec2& getScrollVec()const { return this->player->getScrollVec(); }
	const std::vector<Block*> getBlockList()const { return this->blockList; }
	Player& getPlayer()const { return *this->player; }
};
