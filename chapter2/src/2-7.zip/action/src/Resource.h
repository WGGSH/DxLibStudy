#pragma once

#include <vector>
#include "Singleton.h"
class Resource : public Singleton<Resource> {
	Resource() = default;
	friend Singleton<Resource>;
private:
	int* player;
	int background;
	// int weapon;
	// int enemyNormal;
	// int enemyfly;

public:

	int* getPlayer();
	int getBackGround();
	// int getWeapon();
	// int getEnemyNormal();
	// int getEnemyFly();
};
