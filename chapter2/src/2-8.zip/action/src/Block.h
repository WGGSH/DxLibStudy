#pragma once

#include "Unit.h"
#include "Vec2.h"


class Block :Unit {
private:
	Position startPos; // ���_
	Position endPos; // �I�_
	float angle; // �p�x

	void setAngle();
public:
	Block(InGame&, Position, Position);
	~Block();

	bool update() override;
	void draw()const override;


	bool collision(const Position& pos, float range)const;
	float getAngle()const { return (this->endPos - this->startPos).angle(); }
};
