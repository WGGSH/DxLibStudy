#include "Weapon.h"
#include "DxLib.h"
#include "InGame.h"
#include "Define.h"
#include "Resource.h"

Weapon::Weapon(InGame& _inGame) : Unit(_inGame) {
}

Weapon::Weapon(InGame& _inGame, Position _pos, Vec2 _velocity) :
	Unit(_inGame), pos(_pos), velocity(_velocity) {
	this->accel.y = Define::GRAVITY;
	this->image = Resource::Instance()->getWeapon();
	this->range = 10;
}

Weapon::~Weapon() {
}

bool Weapon::update() {
	// ���W�v�Z
	this->velocity += this->accel;
	this->pos += this->velocity;

	// �G�ւ̍U��
	std::vector<Enemy*> enemyList = this->inGame.getEnemyList();
	for (auto enemy : enemyList) {
		if ((this->pos - enemy->getPos()).length() < (this->range + enemy->getRange())) {
			// �G�ƐڐG������C�G�Ƀ_���[�W��^���āC���g���폜����
			enemy->damage(1);
			return false;
		}
	}

	// ��ʊO�ɂ�����Ԃ�l:false �ŕ�����폜����
	if (this->pos.x<0 || this->pos.x>Define::FIELD_WIDTH || this->pos.y<0 || this->pos.y>Define::FIELD_HEIGHT)return false;

	return true;

}

void Weapon::draw()const {
	// �摜�̕`��
	DxLib::DrawRotaGraph(this->pos.x - this->inGame.getScrollVec().x, this->pos.y - this->inGame.getScrollVec().y,
		1.0f, this->velocity.angle(), this->image, TRUE);
#ifdef _DEBUG
	DxLib::DrawCircle(this->pos.x - this->inGame.getScrollVec().x, this->pos.y - this->inGame.getScrollVec().y,
		this->range, DxLib::GetColor(255, 255, 0), FALSE);
#endif
}