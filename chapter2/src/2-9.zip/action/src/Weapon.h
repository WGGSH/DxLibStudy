#pragma once

#include "Unit.h"
#include "Vec2.h"

class Weapon : Unit {
private:
	Position pos;
	Vec2 velocity;
	Vec2 accel;
	float range;

	int image;
public:
	Weapon(InGame& _inGame);
	Weapon(InGame& _inGame, Position pos, Vec2 velocity);
	~Weapon();
	bool update() override;
	void draw()const override;
};
